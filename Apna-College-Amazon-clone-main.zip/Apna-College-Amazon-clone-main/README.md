# Apna-College-Amazon-clone
<img src="https://github.com/rishikesh0586/Apna-College-Amazon-clone/blob/main/Screenshot%202023-07-06%20203423.png"/>
<img src="https://github.com/rishikesh0586/Apna-College-Amazon-clone/blob/main/Screenshot%202023-07-06%20203512.png"/>
